# Tahti Player MCP API reference

Generated from `packages/tahti-web/src/lib/mcp/registry.ts`. Call methods with the `call` tool: `{ "method": "Domain.method", "params": { ... } }`.

## Playback

What is playing and the transport: play, pause, skip, seek, volume, shuffle and repeat.

### `Playback.getState`

What is playing now, where it is, and the volume, shuffle and repeat settings.

Returns `PlaybackState`.

### `Playback.play`

Resume the loaded item.

Returns `PlaybackState`.

### `Playback.pause`

Pause playback.

Returns `PlaybackState`.

### `Playback.toggle`

Pause if playing, otherwise resume.

Returns `PlaybackState`.

### `Playback.next`

Skip to the next queue item.

Returns `PlaybackState`.

### `Playback.previous`

Go back to the previous queue item.

Returns `PlaybackState`.

### `Playback.seekTo`

Jump to a position in the current track. Live streams and radio cannot seek.

| Parameter | Type | Optional | Description |
| --- | --- | --- | --- |
| `seconds` | number | no | Position from the start, in seconds. |

Returns `PlaybackState`.

### `Playback.setVolume`

Set the volume.

| Parameter | Type | Optional | Description |
| --- | --- | --- | --- |
| `volume` | number | no | From 0 (silent) to 1 (full). |

Returns `PlaybackState`.

### `Playback.setMuted`

Mute or unmute.

| Parameter | Type | Optional | Description |
| --- | --- | --- | --- |
| `muted` | boolean | no | true to mute. |

Returns `PlaybackState`.

### `Playback.setShuffle`

Turn shuffle on or off. Live streams and radio ignore it.

| Parameter | Type | Optional | Description |
| --- | --- | --- | --- |
| `enabled` | boolean | no | true to shuffle. |

Returns `PlaybackState`.

### `Playback.setRepeatMode`

Repeat nothing, the whole queue, or the current track.

| Parameter | Type | Optional | Description |
| --- | --- | --- | --- |
| `mode` | "off" \| "all" \| "one" | no | off, all or one. |

Returns `PlaybackState`.

## Queue

The play queue: list it, jump to an item, remove, move or clear items.

### `Queue.get`

Every queue item in order, with the current one marked.

Returns `QueueItem[]`.

### `Queue.playItem`

Start playing a queue item.

| Parameter | Type | Optional | Description |
| --- | --- | --- | --- |
| `id` | string | no | A queue item id from Queue.get. |

Returns `QueueItem[]`.

### `Queue.remove`

Remove one item from the queue.

| Parameter | Type | Optional | Description |
| --- | --- | --- | --- |
| `id` | string | no | A queue item id from Queue.get. |

Returns `QueueItem[]`.

### `Queue.move`

Move an item to another position.

| Parameter | Type | Optional | Description |
| --- | --- | --- | --- |
| `fromIndex` | number | no | Current position (0 is first). |
| `toIndex` | number | no | New position (0 is first). |

Returns `QueueItem[]`.

### `Queue.clear`

Empty the queue.

Returns `QueueItem[]`.

## Library

Music files in the desktop library: search them, play them, and play local playlists. Desktop app only.

### `Library.search`

Find tracks by title, artist or album. Returns up to 50 tracks per page and the total.

| Parameter | Type | Optional | Description |
| --- | --- | --- | --- |
| `query` | string | no | Words to match; "" lists everything. |
| `offset` | number | yes | Tracks to skip, for the next page. |

Returns `LibraryPage`.

### `Library.totals`

How many tracks the library holds, their total length and size.

Returns `LibraryTotals`.

### `Library.play`

Play library tracks by id, in the order given. Missing files are skipped.

| Parameter | Type | Optional | Description |
| --- | --- | --- | --- |
| `ids` | string[] | no | Track ids from Library.search. |
| `mode` | "now" \| "next" \| "end" | yes | "now" replaces what is playing (default), "next" inserts after the current item, "end" appends to the queue. |

Returns `PlayResult`.

### `Library.playlists`

The local playlists, with their track counts.

Returns `LocalPlaylist[]`.

### `Library.playPlaylist`

Play a local playlist from the start.

| Parameter | Type | Optional | Description |
| --- | --- | --- | --- |
| `id` | string | no | A playlist id from Library.playlists. |
| `mode` | "now" \| "next" \| "end" | yes | "now" replaces what is playing (default), "next" inserts after the current item, "end" appends to the queue. |

Returns `PlayResult`.

## Radio

Radio: the built-in Finnish stations and the radio-browser.info directory of internet radio.

### `Radio.stations`

The built-in stations.

Returns `RadioStation[]`.

### `Radio.search`

Search the internet radio directory by station name.

| Parameter | Type | Optional | Description |
| --- | --- | --- | --- |
| `query` | string | no | Part of the station name. |
| `tag` | string | yes | A genre tag such as "jazz". |

Returns `RadioStation[]`.

### `Radio.play`

Tune in to a built-in station or one found by Radio.search.

| Parameter | Type | Optional | Description |
| --- | --- | --- | --- |
| `id` | string | no | A station id from Radio.stations or Radio.search. |

Returns `PlayResult`.

## Tahti

The Tahti catalog: search public tracks, artists and collections, and play an artist.

### `Tahti.search`

Search Tahti. Track and artist results link to pages on tahti.live.

| Parameter | Type | Optional | Description |
| --- | --- | --- | --- |
| `query` | string | no | What to look for. |
| `type` | "all" \| "tracks" \| "artists" \| "collections" | yes | Limit to one kind of result (default all). |

Returns `TahtiSearchResult`.

### `Tahti.playArtist`

Play an artist's public tracks.

| Parameter | Type | Optional | Description |
| --- | --- | --- | --- |
| `username` | string | no | An artist username from Tahti.search. |
| `mode` | "now" \| "next" \| "end" | yes | "now" replaces what is playing (default), "next" inserts after the current item, "end" appends to the queue. |

Returns `PlayResult`.

## Types

### `PlaybackState`

| Field | Type |
| --- | --- |
| `status` | "idle" \| "loading" \| "playing" \| "paused" \| "error" |
| `error` | string \| null |
| `current` | { id, title, artist } \| null — the loaded queue item |
| `positionSec` | number |
| `durationSec` | number (0 for live streams and radio) |
| `isLive` | boolean — live streams and radio cannot seek or shuffle |
| `volume` | number from 0 to 1 |
| `muted` | boolean |
| `shuffle` | boolean |
| `repeatMode` | "off" \| "all" \| "one" |

### `QueueItem`

| Field | Type |
| --- | --- |
| `index` | number — position, 0 is first |
| `id` | string — pass to Queue.playItem or Queue.remove |
| `title` | string |
| `artist` | string |
| `current` | boolean — true for the loaded item |

### `PlayResult`

| Field | Type |
| --- | --- |
| `queued` | number — items started or added to the queue |

### `LibraryTrack`

| Field | Type |
| --- | --- |
| `id` | string — pass to Library.play |
| `title` | string |
| `artist` | string |
| `album` | string |
| `durationSec` | number \| null |
| `available` | boolean — false when the file is missing |

### `LibraryPage`

| Field | Type |
| --- | --- |
| `total` | number — all matches |
| `tracks` | LibraryTrack[] — this page |

### `LibraryTotals`

| Field | Type |
| --- | --- |
| `trackCount` | number |
| `durationSec` | number \| null |
| `sizeBytes` | number |

### `LocalPlaylist`

| Field | Type |
| --- | --- |
| `id` | string |
| `name` | string |
| `trackCount` | number |
| `durationSec` | number \| null |

### `RadioStation`

| Field | Type |
| --- | --- |
| `id` | string — pass to Radio.play |
| `name` | string |
| `language` | string — built-in stations only |
| `playable` | boolean — built-in stations only; false when there is no stream |
| `country` | string \| null — directory results only |
| `tags` | string[] — directory results only |
| `bitrateKbps` | number \| null — directory results only |

### `TahtiSearchResult`

| Field | Type |
| --- | --- |
| `tracks` | { id, title, artist, durationSec }[] |
| `artists` | { username, name }[] — pass username to Tahti.playArtist |
| `collections` | { slug, name, owner }[] |
