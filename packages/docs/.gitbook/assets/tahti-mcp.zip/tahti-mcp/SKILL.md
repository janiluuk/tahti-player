---
name: tahti-mcp
description: Control the Tahti Player desktop app through its MCP server - play, pause and skip, change the queue, search and play the desktop library and its playlists, tune in to radio, and search Tahti. Use when the user asks to play music, change what is playing, or find something in their library, on the radio or on Tahti.
---

# Tahti Player MCP

The Tahti Player desktop app runs an MCP server at `http://127.0.0.1:8800/mcp` (up to 8809) once the user turns on Settings → Integrations → MCP server. It has four tools.

| Tool | Use |
| --- | --- |
| `list_methods` | No arguments: the domains. `{ "domain": "Library" }`: that domain's methods. |
| `method_details` | `{ "method": "Library.play" }`: parameters (with allowed values and which are optional) and the return type. |
| `describe_type` | `{ "type": "PlaybackState" }`: the fields of a type named in a return type. |
| `call` | `{ "method": "Library.play", "params": { "ids": ["..."] } }`: run a method. |

## Domains

- **Playback**: `getState`, `play`, `pause`, `toggle`, `next`, `previous`, `seekTo` (seconds), `setVolume` (0 to 1), `setMuted`, `setShuffle`, `setRepeatMode` (`off`, `all`, `one`).
- **Queue**: `get`, `playItem` (id), `remove` (id), `move` (fromIndex, toIndex), `clear`.
- **Library** (desktop library): `search` (query, offset), `totals`, `play` (ids, mode), `playlists`, `playPlaylist` (id, mode).
- **Radio**: `stations` (built-in), `search` (query, tag) in the radio-browser.info directory, `play` (id from either).
- **Tahti**: `search` (query, type), `playArtist` (username, mode).

`mode` on the play methods: `now` (default) replaces what is playing, `next` inserts after the current item, `end` appends.

## Recipes

- **Play something from the library**: `Library.search` with the user's words, pick the matching ids (check `available`), then `Library.play`. Confirm with `Playback.getState`.
- **Queue it after this song**: the same with `"mode": "next"`.
- **Put on a radio station**: `Radio.stations` for the built-in ones; otherwise `Radio.search`, then `Radio.play` with the id.
- **Play an artist from Tahti**: `Tahti.search` with `"type": "artists"`, then `Tahti.playArtist` with the username.
- **What is playing?**: `Playback.getState`.

## Errors

A refused call returns an error that says what to fix: an unknown method lists the methods, a missing or mistyped argument names the expected type, and "Nothing is loaded" means start something first. `Library` only works in the desktop app. Live streams and radio cannot seek or shuffle.

Full method and type reference: `references/api-reference.md`.
